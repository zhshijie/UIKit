//
//  MyNavigationViewController.h
//  MyDemo
//
//  Created by sky on 14/6/11.
//  Copyright (c) 2014年 sky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNavigationViewController : UINavigationController

@end
